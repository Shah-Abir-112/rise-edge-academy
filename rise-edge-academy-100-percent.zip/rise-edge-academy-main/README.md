# Rise Edge Academy

**Strong Basics. Better Results.**

Firebase-powered school management web app with public pages, authentication, Admin portal, Student portal and Teacher portal.

## Current working modules

- Firebase Authentication
- Firestore user records
- Admin dashboard
- Admission management
- Sequential Student IDs (`REA-1001`, `REA-1002`, ...)
- Student Management with search/filter/status
- Real-time student loading
- Student ID duplicate protection/repair logic
- Responsive admin UI
- Student and Teacher entry portals

## Firebase

The project is already wired to the Rise Edge Academy Firebase project in the included Firebase config files.

Before production deployment, verify Firebase Authentication providers and Firestore Security Rules in Firebase Console.

## Main structure

```text
rise-edge-academy/
├── index.html
├── login.html
├── register.html
├── css/
├── js/
├── admin/
│   ├── index.html
│   ├── pages/
│   ├── css/
│   └── js/
├── student/
│   └── index.html
└── teacher/
    └── index.html
```

## Deploy

Upload/push the project to GitHub Pages (or another static host) and keep the Firebase configuration enabled for the deployed domain.
